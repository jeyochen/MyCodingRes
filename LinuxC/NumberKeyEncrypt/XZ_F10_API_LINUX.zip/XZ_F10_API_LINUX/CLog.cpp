/*
 * 	Clog.cpp
 *
 *  Created on: Nov 24, 2011
 *  Author: wyl
 */
#include "CLog.h"
#include <stdio.h>
#include <string.h>
#include <string>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <dirent.h>
#include <unistd.h>

#define						LOG_MAX_COUNT					3
#define						MAX_PATH						255


int CLog::GetModuleFilename(char* sModuleName, char* sFileName, int nSize)
{
	int ret = -1;
	char sLine[1024] = { 0 };
	void* pSymbol = (void*) "";
	FILE *fp;
	char *pPath;

	fp = fopen("/proc/self/maps", "r");
	if (fp != NULL)
	{
		while (!feof(fp))
		{
			unsigned long start, end;

			if (!fgets(sLine, sizeof(sLine), fp))
				continue;
			if (!strstr(sLine, " r-xp ") || !strchr(sLine, '/'))
				continue;

			sscanf(sLine, "%lx-%lx ", &start, &end);
			if (pSymbol >= (void *) start && pSymbol < (void *) end)
			{
				char *tmp;
				pPath = strchr(sLine, '/');
				tmp = strrchr(pPath, '\n');
				if (tmp)
					*tmp = 0;
				ret = 0;
				strcpy(sFileName, pPath);
			}
		}
		fclose(fp);
	}
	return ret;
}

CLog::CLog(bool logLevel)
{
	bLogLevel = logLevel;
	char sTemp[MAX_PATH]="";
	GetModuleFilename(sTemp, m_strWorkPath, MAX_PATH);
	strrchr(m_strWorkPath, ('/'))[1] = 0;
}

CLog::~CLog()
{

}

//*******流水函数********
//buf-流水内容字符串
//查找指定文件并找出最久前的一个文件
int CLog::DeleteExpiredFile(const char *strDirPath, char * strFileName)
{
	char tempLog[255] = "";
	strcpy(tempLog, strDirPath);
	strcat(tempLog, "Log");
	int nFileCount = 0;
	time_t curFileTime;
	time_t MostOldFile;
	struct tm *timenow;
	struct tm *timepre;
	int iYear, iMonth, iDay;

	char strDeleteFileName[255] = "";
	bool bFirstFile = true;

	DIR *dirp;
	struct dirent *direntp = NULL;

	if ((dirp = opendir(tempLog)) == NULL)
	{
		return -1;
	}

	while ((direntp = readdir(dirp)) != NULL)
	{
		if (!strcmp(direntp-> d_name, ".") || !strcmp(direntp-> d_name, ".."))
			continue;
		struct stat statbuf;
		char filename[255];
		memset(filename, '\0', 255);
		strcpy(filename, tempLog);
		strcat(filename, "/");
		strcat(filename, direntp->d_name);

		if (stat(filename, &statbuf) == -1)
		{
			return -2;
		}
		timenow = localtime(&statbuf.st_mtime);

		if (S_ISDIR(statbuf.st_mode))
		{
			char dirpath[100];
			memset(dirpath, '\0', 255);

			strcpy(dirpath, strDirPath);
			strcat(dirpath, "/ ");
			strcat(dirpath, direntp->d_name);
			DeleteExpiredFile(dirpath, strFileName);
		}
		else
		{
			curFileTime = statbuf.st_mtime;
			if (bFirstFile)
			{
				bFirstFile = false;
				MostOldFile = curFileTime;

				strcpy(strDeleteFileName, filename);
			}
			else
			{
				timepre = gmtime(&MostOldFile);
				iYear = timepre->tm_year;
				iMonth = timepre->tm_mon;
				iDay = timepre->tm_mday;

				timenow = gmtime(&curFileTime);

				if (iYear > timenow->tm_year)
				{
					MostOldFile = curFileTime;
					strcpy(strDeleteFileName, filename);
				}
				else if ((iMonth > timenow->tm_mon) && (iYear
						== timenow->tm_year))
				{
					MostOldFile = curFileTime;
					strcpy(strDeleteFileName, filename);
				}
				else if (iDay > timenow->tm_mday && iMonth == timenow->tm_mon
						&& iYear == timenow->tm_year)
				{
					MostOldFile = curFileTime;
					strcpy(strDeleteFileName, filename);
				}
			}
			if (nFileCount++ >= LOG_MAX_COUNT)
			{
				//删除最早的文件
				remove(strDeleteFileName);
			}
		}
	}
	closedir(dirp);
	return 1;
}

int CLog::WriteLog(const char *buf)
{
	if (!bLogLevel)
	{
		return 0;
	}
	FILE *fp = NULL;
	time_t now;
	struct tm *timenow;
	char sLogFile[MAX_PATH + 1] = "";

	if (m_mutex.bInit == false)
	{
		m_mutex.bInit = true;
		//创建日志目录
		sprintf(sLogFile, "%sLog",m_strWorkPath);

		//如果目录不存在，则创建
		struct stat statbuf;
		stat(sLogFile, &statbuf);
		if (ENOENT == errno) //If folder  not exist
		{
			mkdir(sLogFile, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
		}
	}
	time(&now);
	timenow = localtime(&now);
	sprintf(sLogFile, "%sLog/XZ_PINPAD_%04d%02d%02d_DLL.txt",
			m_strWorkPath, 1900 + timenow->tm_year, timenow->tm_mon
					+ 1, timenow->tm_mday);

	//删除过期日志
	DeleteExpiredFile(m_strWorkPath, sLogFile);
	m_mutex.Lock();

	fp = fopen(sLogFile, "a+");
	if (fp)
	{
		int processID = getpid();
		time(&now);
		timenow = localtime(&now);
		fprintf(fp, "[%04d-%02d-%02d %02d:%02d:%02d][%s][%d]%s\n", 1900
				+ timenow->tm_year, timenow->tm_mon + 1, timenow->tm_mday,
				timenow->tm_hour, timenow->tm_min, timenow->tm_sec,
				m_strWorkPath, processID, buf);

		fclose(fp);
	}
	m_mutex.Unlock();
	return 0;
}
